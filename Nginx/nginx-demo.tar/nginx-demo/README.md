# README

这个工程是GeekHour的30分钟Nginx入门教程中的示例源码，
视频地址：[30分钟Nginx入门教程](https://www.bilibili.com/video/BV1mz4y1n7PQ)

同时也是一个Docker Compose的简单演示，
可以直接执行`docker compose up`就可以把Nginx课程中用于反向代理的三个go服务启动起来。
